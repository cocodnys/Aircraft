<?php

namespace App\Models;

use CodeIgniter\Model;

class avionsmodel extends Model
{
	protected $table = 'avion';
	protected $primaryKey = 'IDAVION';
	protected $allowedFields = ['IDAVION','PUISSANCE','TYPE','IMMATRICULATION','REFMODELE','NBPLACE','AUTONOMIE','VILLE_AEROCLUB'];
}
?>