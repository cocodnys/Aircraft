<?php 
	if(session()->has('loggedUser')){

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ville</title>
	<link href="inc/styleville.css" type="text/css" rel="stylesheet">
</head>


<body>
	

<div class="villein">

<form action="villeok"> 
	<input type="text" name="ville" id="ville" placeholder="Entrez votre ville..." required><br>
	<button type="submit"style="background-color: Transparent; background-repeat:no-repeat; border: none; cursor: pointer;"><img src="/img/fleche.png" style="height: 25px;" /></button>
</form>



</div>



</body>
</html>
<?php
} else {
	echo "<script type='text/javascript'>document.location.replace('login');</script>";
	session()->setFlashdata('fail','Veuillez vous connecter');
}


?>

