<?php

	if(session('loggedUser') == "admin"){ ?>


<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Admin Pannel</title>
	<link href="inc/stylepannel.css" type="text/css" rel="stylesheet">
</head>
<body>

<div class="pannelcenter">

		<a href="<?php echo base_url('/ville'); ?>">
		<input type="button" value="Acceder au site" /></a>

		<a href="<?php echo base_url('/register'); ?>">
		<input type="button" value="Ajouter un utilisateur" /></a>
		
		<a href="<?php echo base_url('/addclub'); ?>">
		<input type="button" value="Ajouter un aéroclub" /></a>
		
		<a href="<?php echo base_url('/addavion'); ?>">
		<input type="button" value="Ajouter un avion" /></a>
		<center>
		<a href="<?php echo base_url('/logout'); ?>">
		<input type="button" value="Deconnection" style="width: 100px;" /></a>
</center>
</div>

</body>
</html>



<?php } else {


echo "<script type='text/javascript'>document.location.replace('ville');</script>";

}

?>