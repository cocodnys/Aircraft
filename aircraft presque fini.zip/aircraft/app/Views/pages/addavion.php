<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ajouter un avion</title>
	    <link href="inc/styles.css" type="text/css" rel="stylesheet">
</head>
<body>


<div class="retourbutton">
<a href="javascript:history.go(-1)">
	<input type="button" value="< Retour" /></a>
</div>


<div class="login">
<h1>Ajouter un avion</h1>
<form method="post" action="<?= base_url('/addavion'); ?>">
<?= csrf_field(); ?>


	<input type="text" name="immatriculation" placeholder="Immatriculation" required><br>
	<input type="number" name="puissance" placeholder="Puissance (chevaux)" required><br>
	<input type="number" name="nbplace" placeholder="Nombre de places" required><br>
	<input type="number" name="autonomie" placeholder="Autonomie (minutes)" required><br>
	<input type="text" name="villeaeroclub" placeholder="Ville aeroclub" required><br>

	<select name="modele">
		    <option disabled selected>Référence modèle</option>
			<option value="SportStar RTC">SportStar RTC</option>
		    <option value="Pipistrel Velis Electro">Pipistrel Velis Electro</option>
	</select><br>

	<select name="type">
		    <option disabled selected>Type de moteur</option>
			<option value="Essence">Essence</option>
		    <option value="Electrique">Electrique</option>
		</select><br>

	
<?php if(!empty(session()->getFlashdata('fail'))) :  ?>
	<center><p1><?= session()->getFlashdata('fail'); ?></p1></center>
<?php endif ?>

<?php if(!empty(session()->getFlashdata('success'))) :  ?>
	<center><p1><?= session()->getFlashdata('success'); ?></p1></center>
<?php endif ?>

	<button type="submit"style="background-color: Transparent; background-repeat:no-repeat; border: none; cursor: pointer;"><img src="/img/fleche.png" style="height: 25px;" /></button>




</form>
</div>
</body>
</html>