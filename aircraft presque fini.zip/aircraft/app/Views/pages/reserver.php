<?php 
	if(session()->has('loggedUser')){

?>
<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Réserver</title>
	<link href="inc/stylereserver.css" type="text/css" rel="stylesheet">
</head>
<body>


<div class="lapage">

<div class="retourbutton">
<a href="javascript:history.go(-1)">
	<input type="button" value="< Retour" /></a>
</div>


<div class="fiche">
	
	<input type="date" name="date">
	<select name="creneau">
	    <option value="matin">Matin</option>
	    <option value="apres-midi">Après-Midi</option>
	</select><br>

	<button>Réserver</button>


</div>

</div>

</body>
</html>
<?php
} else {
	echo "<script type='text/javascript'>document.location.replace('login');</script>";
	session()->setFlashdata('fail','Veuillez vous connecter');
}


?>