<link href="inc/stylegeo.css" type="text/css" rel="stylesheet">

<?php

if(!empty($_REQUEST['ville'] )){

$ville = $_REQUEST['ville']; 

$servername = 'localhost';
$username = 'coco';
$password = 'coco';
$dbname = 'aircraft';


        
            
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            

$stmt = $conn->prepare("SELECT LATITUDE, LONGITUDE FROM aeroclub where NOMVILLE = '$ville'");


 
$stmt->execute();
$resultat = $stmt->fetchAll();

foreach ($resultat as $ligne) {

			
	$latitude = $ligne['LATITUDE'];
	$longitude = $ligne['LONGITUDE'];

	$coinun = $longitude - 0.116729736328125;
	$coindeux = $latitude - 0.07905866672058;
	$cointrois = $longitude + 0.116729736328125;
	$coinquatre = $latitude + 0.07905866672058;


}


echo "<script type='text/javascript'>document.location.replace('carte?lat=$latitude&long=$longitude&ville=$ville');</script>";

} else {
	?> 
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Erreur</title>
</head>
<body>

<p>Veuillez renseigner une ville</p>

<a href="<?php echo base_url('/ville'); ?>">Retour</a>


</body>
</html>


<?php 
};

?>