<?php

namespace App\Models;

use CodeIgniter\Model;

class UsersModel extends Model
{
	protected $table = 'utilisateur';
	protected $primaryKey = 'IDUTILISATEUR';
	protected $allowedFields = ['IDUTILISATEUR','IDROLE','IDCLUB','NOMUTILISATEUR','MOTDEPASSE','MAIL','TELEPHONE'];
}
?>