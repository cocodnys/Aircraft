<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ville</title>
	<link href="inc/styleville.css" type="text/css" rel="stylesheet">
</head>


<body>

<div class="villein">
<input type="text" name="ville" placeholder="Entrez votre ville..."><br>
<a href="#ville"><img src="/img/fleche.png"></a>
</div>




</body>
</html>