<?php

$avion = $_GET['avion'];  

$servername = 'localhost';
$username = 'coco';
$password = 'coco';
$dbname = 'aircraft';
 

        
            
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            

$stmt = $conn->prepare("SELECT aeroclub.LATITUDE, aeroclub.LONGITUDE FROM aeroclub inner join avion on aeroclub.NOMVILLE = avion.VILLE_AEROCLUB where avion.IMMATRICULATION = '$avion'");

 
 
$stmt->execute();
$resultat = $stmt->fetchAll();




foreach ($resultat as $ligne) {

			
	$latitude = $ligne['LATITUDE'];
	$longitude = $ligne['LONGITUDE'];

	$coinun = $longitude - 0.116729736328125;
	$coindeux = $latitude - 0.07905866672058;
	$cointrois = $longitude + 0.116729736328125;
	$coinquatre = $latitude + 0.07905866672058;


}


echo "<script type='text/javascript'>document.location.replace('carte?lat=$latitude&long=$longitude');</script>";

?>