<?php include 'php/test.php'?>
<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Details</title>
	<link href="inc/styledetails.css" type="text/css" rel="stylesheet">
</head>
<body>


<div class="lapage">

<div class="retourbutton">
<a href="javascript:history.go(-1)">
	<input type="button" value="< Retour" /></a>
</div>

<div class="fiche">
	<div class="phototexte">
		<table>
			<tr>
				<td>Immatriculation : <?php echo "$latitude"; ?></td>
				<td>Type (Avion, ULM …) : Avion</td>
				<td>Référence du modèle : SportStar RTC</td>
				<td>Nombre de places : 2</td>
				<td>Puissance : 100</td>
				<td>Autonomie : 8H00</td>

			</tr>
		</table>

	<img src="/img/avion.jpg">

	</div>

<div class="button"><a href="<?php echo base_url('/reserver'); ?>">
	<input type="button" value="Reserver" /></a>
</div>


</div>

</div>

</body>
</html>