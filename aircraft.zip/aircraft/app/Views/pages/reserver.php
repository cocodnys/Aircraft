<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Details</title>
	<link href="inc/stylereserver.css" type="text/css" rel="stylesheet">
</head>
<body>


<div class="lapage">

<div class="retourbutton">
<a href="javascript:history.go(-1)">
	<input type="button" value="< Retour" /></a>
</div>

<div class="fiche">
	<div class="calendrier">
		<table>
		<tr>
			<th></th>
			<th>Lundi</th>
			<th>Mardi</th>
			<th>Mercredi</th>
			<th>Jeudi</th>
			<th>Vendredi</th>
			<th>Samedi</th>
			<th>Dimanche</th>
		</tr>

		<tr>
			<td>Matin</td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
		</tr>
		<tr>
			<td>Après-midi</td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
			<td><button>Reserver</button></td>
		</tr>
		

			
		</table>


	</div>



</div>

</div>

</body>
</html>