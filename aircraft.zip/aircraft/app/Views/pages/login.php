<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	    <link href="inc/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="login">
<h1>Se connecter</h1>
<form method="post" action="<?= base_url('/check'); ?>">
<?= csrf_field(); ?>

<input type="text" name="username" placeholder="User" required><br>
<center><span><?= isset($validation) ? display_error($validation, 'username') : '' ?></span></center>

<input type="password" name="password" placeholder="Password" required><br>
<center><span><?= isset($validation) ? display_error($validation, 'password') : '' ?></span></center>

<?php if(!empty(session()->getFlashdata('fail'))) :  ?>
	<center><p1><?= session()->getFlashdata('fail'); ?></p1></center>
<?php endif ?>





<button type="submit"style="background-color: Transparent; background-repeat:no-repeat; border: none; cursor: pointer;"><img src="/img/fleche.png" style="height: 25px;" /></button>





</form>
</div>
</body>
</html>