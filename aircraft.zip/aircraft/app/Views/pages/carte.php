<?php 
$ville = $_GET['ville'];

$servername = 'localhost';
$username = 'coco';
$password = 'coco';
$dbname = 'aircraft';
            
            
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      

$stmt = $conn->prepare("SELECT IMMATRICULATION, VILLE_AEROCLUB FROM avion where ville_aeroclub != 'EN_VOL' AND ville_aeroclub = '$ville'");



$stmt->execute();
$resultat = $stmt->fetchAll();


if(isset($_GET['lat']) && isset($_GET['long'])){

}

?>


<?php include 'php/test.php'?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Carte</title>
	<link href="inc/stylecarte.css" type="text/css" rel="stylesheet">
</head>
<body>

	<div class="menu">

<div class="autreville">
	<a href="<?php echo base_url('/ville'); ?>">
	<input type="button" value="Changer de ville" /></a>
</div>

<?php if(isset($_GET['lat']) && isset($_GET['long'])){

	$latitude = $_GET['lat'];
	$longitude = $_GET['long'];
	
	$coinun = $_GET['long'] - 0.116729736328125;
	$coindeux = $_GET['lat'] - 0.07905866672058;
	$cointrois = $_GET['long'] + 0.116729736328125;
	$coinquatre = $_GET['lat'] + 0.07905866672058;

?>

	<iframe width="500" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo $coinun; ?>%2C<?php echo $coindeux; ?>%2C<?php echo $cointrois; ?>%2C<?php echo $coinquatre; ?>&amp;layer=mapnik&amp;marker=<?php echo $latitude; ?>%2C<?php echo $longitude; ?>" style="border: 2px solid black; border-radius: 10px;"></iframe><br>

<?php }else { ?>

	<iframe width="500" height="300" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo $coinun; ?>%2C<?php echo $coindeux; ?>%2C<?php echo $cointrois; ?>%2C<?php echo $coinquatre; ?>&amp;layer=mapnik&amp;marker=<?php echo $latitude; ?>%2C<?php echo $longitude; ?>" style="border: 2px solid black; border-radius: 10px;"></iframe><br>

<?php } ?>

	<div class="sousmenu">

		<select name="moteur">
		    <option disabled selected>Type de moteur</option>
			<option value="Essence">Essence</option>
		    <option value="Electrique">Electrique</option>
		</select>

	<input type="search" name="rechercher" placeholder="Rechercher...">
	</div>
<div class="tableau">
	<?php foreach ($resultat as $ligne) { ?>
	<div class="liste">
		<table>
			<tr>
		        <td><p><?php echo $ligne['IMMATRICULATION'];?></p></td>
		        <td><p>-</p></td>
		        <td><p><?php echo $ligne['VILLE_AEROCLUB'];?></p></td>           
		    </tr>
		    
		</table>

	<form action="geolocaliser.php" method="post"> 
		<div class="button"><p>
			
			<a href="<?php echo base_url('/details');?>?avion=<?php echo $ligne['IMMATRICULATION'] ?>">Détails</a>
			<a href="<?php echo base_url('/geolocaliser/');?>?avion=<?php echo $ligne['IMMATRICULATION'] ?>">Géolocaliser</a>
			<a href="<?php echo base_url('/reserver'); ?>">Réserver</a></p>

		</div>
	</form>		
	</div>
<?php } ?>
</div>


</div>



</div>

</body>
</html>