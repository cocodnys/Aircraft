<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Details</title>
	<link href="inc/styledetails.css" type="text/css" rel="stylesheet">
</head>
<body>

<div class="fiche">
	<div class="phototexte">
		<table>
			<tr>

				<td>Immatriculation : F-HTZZ</td>
				<td>Type (Avion, ULM …) : Avion</td>
				<td>Référence du modèle : SportStar RTC</td>
				<td>Nombre de places : 2</td>
				<td>Puissance : 100</td>
				<td>Autonomie : 8H00</td>

			</tr>
		</table>

	<img src="/img/avion.jpg">

	</div>

<div class="button"><p>
	<input type="button" onclick="location.href='#reserver';" value="Reserver" />
</div>


</div>



</body>
</html>