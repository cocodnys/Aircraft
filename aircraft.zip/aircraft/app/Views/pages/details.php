<?php

$avion = $_GET['avion'];

$servername = 'localhost';
$username = 'coco';
$password = 'coco';
$dbname = 'aircraft';
            
            
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
      

$stmt = $conn->prepare("SELECT * FROM avion where IMMATRICULATION = '$avion'");



$stmt->execute();
$resultat = $stmt->fetchAll();



?>

<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Details</title>
	<link href="inc/styledetails.css" type="text/css" rel="stylesheet">
</head>
<body>


<div class="lapage">

<div class="retourbutton">
<a href="javascript:history.go(-1)">
	<input type="button" value="< Retour" /></a>
</div>

<div class="fiche">
	<div class="phototexte">
		<?php foreach ($resultat as $ligne) { ?>
		<table>
			<tr>
				<td>Immatriculation : <?php echo $ligne['IMMATRICULATION'] ?></td>
				<td>Type (Avion, ULM …) : <?php echo $ligne['TYPE'] ?></td>
				<td>Référence du modèle : <?php echo $ligne['REFMODELE'] ?></td>
				<td>Nombre de places : <?php echo $ligne['NBPLACE'] ?></td>
				<td>Puissance : <?php echo $ligne['PUISSANCE'] ?></td>
				<td>Autonomie : <?php echo $ligne['AUTONOMIE'] ?></td>

			</tr>
		</table>
		<?php } ?>
	<img src="/img/avion.jpg">

	</div>

<div class="button"><a href="<?php echo base_url('/reserver'); ?>">
	<input type="button" value="Reserver" /></a>
</div>


</div>

</div>

</body>
</html>