<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Ville</title>
</head>

<style type="text/css">
	@import url('https://fonts.googleapis.com/css2?family=Aleo&display=swap');
	body{
		margin: 0;
    	padding: 0;
    	margin-top: 120px;
    	
	}
	header{
		display: block;
  		position: fixed;
		top: 0;
		width: 100%;
		margin-left: auto;
		margin-right: auto;
		background-color: white;
		
	}
	header:after {
    content: ""; /* This is necessary for the pseudo element to work. */ 
    display: block; /* This will put the pseudo element on its own line. */
    margin: 0 auto; /* This will center the border. */
    width: 98%; /* Change this to whatever width you want. */
    padding-top: 0px; /* This creates some space between the element and the border. */
    border-bottom: 1px solid black; /* This creates the border. Replace black with whatever color you want. */
	}
	footer{
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 80px; 
		margin-left: auto;
		margin-right: auto;
		background-color: white;
	}

	footer p{
		padding-top: ;
		text-align: center;
	}
	hr{
		border: none;
	    border-top: 1px solid black;
	    color: black;
	    overflow: hidden;
	    text-align: center;
	    width: 98%;
	}

	.logo {
		  	display: block;
		  	margin-left: auto;
		  	margin-right: auto;
		  	height: 90px;
		  	margin-top: 20px;
		  	margin-bottom: 10px;
		}

	p.noms{
		font-size: 15px;
		margin-top: -15px;
		padding-bottom: 20px;
	}






a img{
	height: 20px;
}

.villein{

text-align: center;
margin: 0;
position: absolute;
top: 50%;
left: 50%;
transform: translate(-50%, -50%);
}
.villein input{
	font-family: Aleo;
	padding-top: 3px;
	border: 2px solid black;
	border-radius: 10px;
	height: 20px;
	padding-left: 10px;
	margin-bottom: 10px;
}
</style>
<body>
	<header>
		<img class="logo" src="logo.png">
		
	</header>


<div class="villein">
<input type="text" name="ville" placeholder="Entrez votre ville..."><br>
<a href="#ville"><img src="fleche.png"></a>
</div>


<footer>
	<hr>
	<p>Aircraft  ©2022</p>
	<p class="noms">Corentin Denys / Vincent Urbanski / Hugo Cools</p>

</footer>

</body>
</html>