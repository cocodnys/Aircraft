
<style type="text/css">
	@import url('https://fonts.googleapis.com/css2?family=Aleo&display=swap');


	footer{
		position: absolute;
		bottom: 0;
		width: 100%;
		height: 80px; 
		margin-left: auto;
		margin-right: auto;
		background-color: white;

	}

	footer{
		font-size: 20;
		text-align: center;
	}
	hr{
		border: none;
	    border-top: 1px solid black;
	    color: black;
	    overflow: hidden;
	    text-align: center;
	    width: 98%;
	}


	.noms{
		
		margin-top: ;
		padding-bottom: 20px;
	}
</style>
<body>

<footer>
	<hr>

	Aircraft  ©2022
	<div class="noms">Corentin Denys / Vincent Urbanski / Hugo Cools</div>

</footer>

</body>
</html>