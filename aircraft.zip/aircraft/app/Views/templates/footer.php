
<style type="text/css">
	@import url('https://fonts.googleapis.com/css2?family=Aleo&display=swap');


	footer{
		position: absolute;
		bottom: 0;
		width: 100%;
		height: 80px; 
		margin-left: auto;
		margin-right: auto;
		background-color: white;

	}

	footer p{
		
		text-align: center;
	}
	hr{
		border: none;
	    border-top: 1px solid black;
	    color: black;
	    overflow: hidden;
	    text-align: center;
	    width: 98%;
	}


	p.noms{
		font-size: 15px;
		margin-top: -15px;
		padding-bottom: 20px;
	}
</style>
<body>

<footer>
	<hr>
	<p>Aircraft  ©2022</p>
	<p class="noms">Corentin Denys / Vincent Urbanski / Hugo Cools</p>

</footer>

</body>
</html>