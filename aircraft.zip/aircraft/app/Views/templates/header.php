<!DOCTYPE html>
<html>
<head>
	<link rel="icon" href="/img/logopetit.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
</head>

<style type="text/css">

	header{
		display: block;
  		position: fixed;
		top: 0;
		width: 100%;
		margin-left: auto;
		margin-right: auto;
		background-color: white;
		
	}
	header:after {
    content: ""; /* This is necessary for the pseudo element to work. */ 
    display: block; /* This will put the pseudo element on its own line. */
    margin: 0 auto; /* This will center the border. */
    width: 98%; /* Change this to whatever width you want. */
    padding-top: 0px; /* This creates some space between the element and the border. */
    border-bottom: 1px solid black; /* This creates the border. Replace black with whatever color you want. */
	}


	.logo {
		  	display: block;
		  	margin-left: auto;
		  	margin-right: auto;
		  	height: 90px;
		  	margin-top: 20px;
		  	margin-bottom: 10px;
		}

</style>
<body>
	<header>
		<img class="logo" src="/img/logo.png">
		
	</header>
	 <div class="page">
            <div class="contenu">

</body>
</html>