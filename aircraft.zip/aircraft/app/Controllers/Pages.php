<?php
// namespace : espace de nom 
namespace App\Controllers;
//
class Pages extends BaseController
{
    public function index()
    {
        return view('welcome_message');
    }

    /** AFFICHE LA PAGE */
    public function view($page = 'login')
    {
        // récupére le nom de la page demandée dans l'url
        // l'insére dans le tableau $data[] à la clée "titre"
        $data['title'] = ucfirst($page); // Met en Capitale la 1ere lettre

        // les templates isoles les parties identique du codes (évite les répétition) 
        echo view('templates/header', $data);
        echo view('pages/'.$page, $data);
	    echo view('templates/footer', $data);
    }
}