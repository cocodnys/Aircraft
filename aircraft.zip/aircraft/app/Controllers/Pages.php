<?php
// namespace : espace de nom 
namespace App\Controllers;
//
class Pages extends BaseController
{
    protected static $data = array();



    /** AFFICHE LA PAGE */
    public function view($page = 'login')
    {
        // récupére le nom de la page demandée dans l'url
        // l'insére dans le tableau $data[] à la clée "titre"

        // les templates isoles les parties identique du codes (évite les répétition) 
        echo view('templates/header', self::$data);
        echo view('pages/'.$page, self::$data);
    }
}