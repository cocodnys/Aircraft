<?php namespace App\Controllers;
 
use CodeIgniter\Controller;
use App\Models\AirModel;
 
class Aircraft extends Controller
{
    public function view($page, $data)  {
	$data['title'] = "Aircraft : ". ucfirst($page); // ucfirst() : Met en Capitale la 1ere lettre
	echo view('templates/header', $data);
	echo view('pages/fabricant/'.$page, $data);
	echo view('templates/footer', $data);
    }

}
    