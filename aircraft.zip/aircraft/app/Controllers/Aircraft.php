<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Libraries\Hash;
 
class Aircraft extends Controller
{
	protected static $data = array();

	public function view($page)  {
		echo view('templates/header', self::$data);
		echo view('pages/'.$page, self::$data);
		echo view('templates/footer', self::$data);
	}


	public function nofooter($page)  {
		echo view('templates/header', self::$data);
		echo view('pages/'.$page, self::$data);
	}

	public function __construct(){
		helper(['url','form']);
	}


	public function login(){
		
		Aircraft::nofooter('login');
	}

	public function register(){
		
		Aircraft::view('register');
	}

	public function carte(){
		
		Aircraft::view('carte');
	}

	public function choixville(){
		Aircraft::view('ville');
	}

	public function details(){
		Aircraft::view('details');
	}

	public function reserver(){
		Aircraft::view('reserver');
	}
	
	public function geolocaliser(){
		Aircraft::view('php/geolocaliser');
	}

	public function ville(){
		Aircraft::view('php/ville');
	}

	public function save(){
		$validation = $this->validate([
				'username' => 'required',
				'password' => 'required',
				'email' => 'required|valid_email|is_unique[utilisateur.MAIL]',
				'tel' => 'required|is_unique[utilisateur.TELEPHONE]'
		]);

		if(!$validation){
			return Aircraft::view('register',['validation'=>$this->validator]);
		} else{
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$mail = $this->request->getPost('email');
			$tel = $this->request->getPost('tel');

			$values = [
				'NOMUTILISATEUR'=>$username,
				'MOTDEPASSE'=>Hash::make($password),
				'MAIL'=>$mail,
				'TELEPHONE'=>$tel,
			]; 

			$userModel = new \App\Models\UsersModel();
			$query = $userModel->insert($values);
			if(!$query){
				return redirect()->back()->with('fail','Une erreur s\'est produite');
				//return redirect()->to('login')->with('fail','Something went wrong');
			} else {
				return redirect()->to('register')->with('success','Utilisateur enregistré.');
			}

		}
	}

	function check(){

		$validation = $this->validate([
			'username'=>[
				'rules'=>'required|is_not_unique[utilisateur.NOMUTILISATEUR]',
				'error'=>[
					'required'=>'Votre nom d\'utilisateur est requis',
					'is_not_unique'=>"Ce nom d\'utilisateur n\'est pas enregistré"
				]
			],
			
			'password'=>[
				'rules'=>'required',
				'error'=>[
					'required'=>'Votre mot de passe est requis',
				]	
			]		

		]);

		if(!$validation){
			return redirect()->to('login')->with('fail','Ce nom d\'utilisateur n\'est pas enregistré');
		} else {
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$userModel = new \App\Models\UsersModel();
			$user_info = $userModel->where('NOMUTILISATEUR',$username)->first();
			
				if(password_verify($password, $user_info['MOTDEPASSE'])){
					$user_name = $user_info['NOMUTILISATEUR'];
					session()->setFlashdata('success', 'Mot de passe valide');
					session()->set('loggedUser', $user_name);
					return redirect()->to('/ville');
				} else {
					session()->setFlashdata('fail', 'Mauvais mot de passe');
					return redirect()->to('/login')->withInput();
				}

			
		}

	}

	function logout(){
		if(session()->has('loggedUser')){
			session()->remove('loggedUser');
			return redirect()->to('/login')->with('fail','Vous êtes déconnecté');
		}
	}

	
}
?>