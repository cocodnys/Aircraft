<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Libraries\Hash;
 
class Aircraft extends Controller
{
	protected static $data = array();

	public function view($page)  {
		echo view('templates/header', self::$data);
		echo view('pages/'.$page, self::$data);
		echo view('templates/footer', self::$data);
	}


	public function nofooter($page)  {
		echo view('templates/header', self::$data);
		echo view('pages/'.$page, self::$data);
	}

	public function __construct(){
		helper(['url','form']);
	}


	public function login(){
		
		Aircraft::nofooter('login');
	}

	public function register(){
		
		Aircraft::nofooter('register');
	}

	public function carte(){
		
		Aircraft::view('carte');
	}

	public function choixville(){
		Aircraft::view('ville');
	}

	public function details(){
		Aircraft::view('details');
	}

	public function reserver(){
		Aircraft::view('reserver');
	}
	
	public function geolocaliser(){
		Aircraft::view('php/geolocaliser');
	}

	public function ville(){
		Aircraft::view('php/ville');
	}

	public function save(){
		$validation = $this->validate([
				'username' => 'required',
				'password' => 'required',
				'email' => 'required|valid_email|is_unique[utilisateur.MAIL]',
				'tel' => 'required|is_unique[utilisateur.TELEPHONE]'
		]);

		if(!$validation){
			return view('pages/register',['validation'=>$this->validator]);
		} else{
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$mail = $this->request->getPost('email');
			$tel = $this->request->getPost('tel');

			$values = [
				'NOMUTILISATEUR'=>$username,
				'MOTDEPASSE'=>Hash::make($password),
				'MAIL'=>$mail,
				'TELEPHONE'=>$tel,
			]; 

			$userModel = new \App\Models\UsersModel();
			$query = $userModel->insert($values);
			if(!$query){
				return redirect()->back()->with('fail','Une erreur s\'est produite');
				//return redirect()->to('login')->with('fail','Something went wrong');
			} else {
				return redirect()->to('register')->with('success','Vous avez maintenant un compte');
			}

		}
	}

	function check(){

		$validation = $this->validate([
			'username'=>[
				'rules'=>'required|is_not_unique[utilisateur.NOMUTILISATEUR]',
				'error'=>[
					'required'=>'Votre nom d\'utilisateur est requis',
					'is_not_unique'=>'Ce nom d\'utilisateur n\'est pas enregistré'
				]
			],
			
			'password'=>[
				'rules'=>'required',
				'error'=>[
					'required'=>'Votre mot de passe est requis',
				]	
			]		

		]);

		if(!$validation){
			return view('pages/login',['validation'=> $this->validator]);
		} else {
			$username = $this->request->getPost('username');
			$password = $this->request->getPost('password');
			$userModel = new \App\Models\UsersModel();
			$user_info = $userModel->where('NOMUTILISATEUR',$username)->first();
			$check_password = Hash::check($password, $user_info['MOTDEPASSE']);

			if(!$check_password){
				session()->setFlashdata('fail', 'Mauvais mot de passe');
				return redirect()->to('/login')->withInput();
			} else {
				$user_id = $user_info['IDUTILISATEUR'];
				session()->set('loggedUser', $user_id);
				return redirect()->to('/ville');
			}
		}

	}

	
}
?>