<?php
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\fabModel;
 
class Aircraft extends Controller
{
	protected static $data = array();

	public function view($page)  {
		echo view('templates/header', self::$data);
		echo view('pages/'.$page, self::$data);
		echo view('templates/footer', self::$data);
	}

	public function carte(){
		
		Aircraft::view('carte');
	}

	public function ville(){
		Aircraft::view('ville');
	}

	public function details(){
		Aircraft::view('details');
	}

	public function reserver(){
		Aircraft::view('reserver');
	}

}