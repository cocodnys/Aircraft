<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login</title>
	    <link href="inc/styles.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="login">
	<h1>Se connecter</h1>
<input type="text" name="Login" placeholder="User"><br>
<input type="password" name="password" placeholder="Password"><br>
<a href="#go"><img src="/img/fleche.png"></a>
</div>
</body>
</html>