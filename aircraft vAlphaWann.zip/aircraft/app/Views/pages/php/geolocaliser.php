<?php 


$servername = 'localhost';
$username = 'coco';
$password = 'coco';
$dbname = 'aircraft';
            
            
$conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
            

$stmt = $conn->prepare('SELECT aeroclub.IDCLUB,aeroclub.NOMCLUB,aeroclub.NOMVILLE,aeroclub.LATITUDE,aeroclub.LONGITUDE,avion.IMMATRICULATION FROM aeroclub inner join avion on aeroclub.NOMVILLE = avion.VILLE_AEROCLUB');

 
 
$stmt->execute();
$resultat = $stmt->fetchAll();



?>