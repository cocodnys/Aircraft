<?php


$latitude = 48.866667;
$longitude = 2.333333;

$coinun = $longitude - 0.116729736328125;
$coindeux = $latitude - 0.07905866672058;
$cointrois = $longitude + 0.116729736328125;
$coinquatre = $latitude + 0.07905866672058;


?>